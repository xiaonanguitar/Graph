# 任务调度服务 (Task Scheduling Service)

## 业务流程概述

任务调度服务负责管理和分配工作流中的任务，确保任务能够在合适的时间分配给合适的处理人员。它监控流程中的任务节点，当流程执行到达任务节点时，自动创建任务并分配给指定的用户或角色。

### 业务流程图

```mermaid
graph TD
    A[流程执行到达任务节点] --> B[任务创建]
    B --> C[任务分配]
    C --> D[任务待办列表]
    D --> E[任务处理]
    E --> F[任务完成]
    F --> G[流程继续执行]
    
    style A fill:#e1f5fe
    style B fill:#f3e5f5
    style C fill:#e8f5e8
    style D fill:#fff3e0
    style E fill:#e0f2f1
    style F fill:#f3e5f5
    style G fill:#e8f5e8
```

## 核心功能实现

### 1. 任务创建机制

任务调度服务基于流程定义中的任务节点自动创建任务。当流程执行到达用户任务(User Task)节点时，系统会自动生成一个待办任务。

### 2. 任务分配策略

任务可以通过以下方式进行分配：
- 指定具体的任务办理人(assignee)
- 分配给候选用户或组(candidate users/groups)
- 通过表达式动态计算分配人

```java
// 在ExecutionController中查询特定用户的待办任务
@GetMapping("/tasks/assignee/{assignee}")
public ResponseEntity<List<Map<String, Object>>> getTasksByAssignee(@PathVariable String assignee) {
    List<Task> tasks = taskService.createTaskQuery()
            .taskAssignee(assignee)
            .orderByTaskCreateTime()
            .desc()
            .list();

    List<Map<String, Object>> result = new ArrayList<>();
    for (Task task : tasks) {
        Map<String, Object> taskInfo = new HashMap<>();
        taskInfo.put("id", task.getId());
        taskInfo.put("name", task.getName());
        taskInfo.put("assignee", task.getAssignee());
        taskInfo.put("owner", task.getOwner());
        taskInfo.put("createTime", task.getCreateTime());
        taskInfo.put("dueDate", task.getDueDate());
        taskInfo.put("priority", task.getPriority());
        taskInfo.put("processInstanceId", task.getProcessInstanceId());
        taskInfo.put("processDefinitionId", task.getProcessDefinitionId());
        taskInfo.put("taskDefinitionKey", task.getTaskDefinitionKey());
        taskInfo.put("description", task.getDescription());
        result.add(taskInfo);
    }

    return ResponseEntity.ok(result);
}
```

### 3. 任务状态管理

任务调度服务维护任务的生命周期，包括：
- 任务创建
- 任务分配
- 任务领取
- 任务完成
- 任务删除

### 4. 依赖注入与服务组件

任务调度服务主要依赖于[TaskService](file://E:\Code\Java\flowable\src\main\java\org\flowable\engine\TaskService.java#L53-L1276)来管理任务：

```java
@Service
public class WorkflowServiceImpl implements WorkflowService {

    @Autowired
    private TaskService taskService;  // 任务管理服务
    
    // 查询个人待办任务
    @Override
    public List<Task> getPersonalTasks(String assignee) {
        return taskService.createTaskQuery()
                .taskAssignee(assignee)
                .list();
    }

    // 完成任务
    @Override
    public void completeTask(String taskId, Map<String, Object> variables) {
        taskService.complete(taskId, variables);
    }
}
```

## 服务实现方案

### 1. 任务查询接口

提供多种任务查询接口：
- `/api/execution/tasks`: 查询所有待办任务
- `/api/execution/tasks/assignee/{assignee}`: 查询特定用户的待办任务
- `/api/execution/process-instance/{processInstanceId}/tasks`: 查询特定流程实例的任务

### 2. 任务操作接口

- 任务完成接口：当用户完成任务后调用，使流程继续执行
- 任务委托接口：将任务委托给其他人处理
- 任务转交接口：将任务转交给其他人处理

### 3. 任务监控

任务调度服务提供任务监控功能，可以实时查看任务的处理状态，包括：
- 任务创建时间
- 任务分配人
- 任务优先级
- 任务截止日期

### 4. 任务通知

当新任务创建并分配给用户时，系统可以发送通知提醒用户及时处理任务。

## 业务价值

任务调度服务确保了工作流中的任务能够高效地分配和处理，提高了业务流程的执行效率。通过自动化的任务分配和监控，减少了人工干预的需求，降低了任务遗漏的风险，保证了业务流程的顺畅运行。