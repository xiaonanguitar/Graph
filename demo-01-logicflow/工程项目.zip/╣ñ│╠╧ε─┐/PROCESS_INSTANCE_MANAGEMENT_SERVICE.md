# 流程实例管理服务 (Process Instance Management Service)

## 业务流程概述

流程实例管理服务负责整个工作流生命周期的管理，从流程实例的创建、执行、监控到最终的结束或删除。它提供了对运行中和已完成流程实例的全面管控能力，确保业务流程按照预定义的规则正常执行。

### 业务流程图

```mermaid
graph TD
    A[启动流程] --> B[创建流程实例]
    B --> C[流程实例运行]
    C --> D{流程执行状态}
    D -->|正常执行| E[等待任务处理]
    D -->|异常终止| F[流程实例异常]
    D -->|完成| G[流程实例结束]
    E --> H[任务完成继续执行]
    H --> D
    F --> I[流程实例删除]
    G --> J[流程实例归档]
    
    style A fill:#e1f5fe
    style B fill:#f3e5f5
    style C fill:#e8f5e8
    style D fill:#fff3e0
    style E fill:#e0f2f1
    style H fill:#e8f5e8
    style G fill:#d1f2eb
    style F fill:#fdeada
    style I fill:#fadbd8
    style J fill:#d5f4e6
```

## 核心功能实现

### 1. 流程实例启动

流程实例管理服务通过[RuntimeService](file://E:\Code\Java\flowable\src\main\java\org\flowable\engine\RuntimeService.java#L56-L1307)启动新的流程实例：

```java
// 启动流程实例
@Override
public ProcessInstance startProcess(String processDefinitionKey, String businessKey, Map<String, Object> variables) {
    return runtimeService.startProcessInstanceByKey(processDefinitionKey, businessKey, variables);
}
```

启动流程实例时可以传入业务键(businessKey)和流程变量(variables)，业务键用于关联外部业务系统，流程变量用于在流程执行过程中传递数据。

### 2. 流程实例查询

提供对运行中和历史流程实例的查询功能：

```java
// 在ExecutionController中查询所有运行中的流程实例
@GetMapping("/process-instances")
public ResponseEntity<List<Map<String, Object>>> getRunningProcessInstances() {
    List<ProcessInstance> processInstances = runtimeService.createProcessInstanceQuery()
            .orderByProcessDefinitionId()
            .desc()
            .list();

    List<Map<String, Object>> result = new ArrayList<>();
    for (ProcessInstance instance : processInstances) {
        Map<String, Object> instanceInfo = new HashMap<>();
        instanceInfo.put("id", instance.getId());
        instanceInfo.put("processDefinitionId", instance.getProcessDefinitionId());
        instanceInfo.put("processDefinitionKey", instance.getProcessDefinitionKey());
        instanceInfo.put("processDefinitionName", instance.getProcessDefinitionName());
        instanceInfo.put("businessKey", instance.getBusinessKey());
        instanceInfo.put("startTime", instance.getStartTime());
        instanceInfo.put("startUserId", instance.getStartUserId());
        result.add(instanceInfo);
    }

    return ResponseEntity.ok(result);
}
```

### 3. 流程实例监控

流程实例管理服务提供全面的监控功能，包括：

- 实例基本信息：ID、定义、开始时间、业务键等
- 执行路径：当前活动节点和执行路径
- 历史记录：已完成的活动和任务
- 变量信息：当前流程变量状态

### 4. 流程实例控制

支持对流程实例的控制操作：

```java
// 删除流程实例
@Override
public void deleteProcessInstance(String processInstanceId, String deleteReason) {
    runtimeService.deleteProcessInstance(processInstanceId, deleteReason);
}
```

### 5. 依赖注入与服务组件

流程实例管理服务依赖于多个Flowable服务组件：

```java
@Service
public class WorkflowServiceImpl implements WorkflowService {

    @Autowired
    private RuntimeService runtimeService;    // 运行时服务，管理流程实例

    @Autowired
    private HistoryService historyService;    // 历史服务，管理历史数据
}
```

## 服务实现方案

### 1. 实例启动接口

- `/api/execution/start-process`: 启动流程实例
- 支持传入流程定义键、业务键和流程变量

### 2. 实例查询接口

- `/api/execution/process-instances`: 查询所有运行中的流程实例
- `/api/execution/process-instance/{processInstanceId}`: 查询特定流程实例详情
- `/api/execution/process-instance/{processInstanceId}/tasks`: 查询流程实例的任务
- `/api/execution/process-instance/{processInstanceId}/executions`: 查询流程实例的执行路径

### 3. 历史数据查询

- `/api/execution/process-instance/{processInstanceId}/history-activities`: 查询历史活动
- `/api/execution/process-instance/{processInstanceId}/history-tasks`: 查询历史任务

### 4. 实例控制接口

- 删除流程实例
- 激活/挂起流程实例
- 修改流程变量

### 5. 监控与统计

提供流程实例的实时监控和统计功能：
- 流程实例数量统计
- 平均处理时间统计
- 异常流程实例统计

## 业务价值

流程实例管理服务为企业提供了对业务流程的全面管控能力，确保业务流程按照预期执行。通过完善的监控和管理功能，企业可以实时了解业务流程的状态，及时发现和处理异常情况，提高业务流程的可靠性和可控性。同时，通过流程实例的生命周期管理，企业可以优化业务流程，提升整体运营效率。